<?php
// FUNGSI UNTUK BARANG
function getAllBarang() {
    global $conn;
    if (!$conn) {
        die("Koneksi database tidak tersedia");
    }
    $result = mysqli_query($conn, "SELECT * FROM barang");
    if (!$result) {
        die("Error: " . mysqli_error($conn));
    }
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function getBarangById($id) {
    global $conn;
    if (!$conn) {
        die("Koneksi database tidak tersedia");
    }
    $result = mysqli_query($conn, "SELECT * FROM barang WHERE id_barang='$id'");
    if (!$result) {
        die("Error: " . mysqli_error($conn));
    }
    return mysqli_fetch_assoc($result);
}
function tambahBarang($nama_barang, $harga, $foto, $stock) { 
    global $conn;
    if (!$conn) {
        die("Koneksi database tidak tersedia");
    }
    
    // Handle foto kosong - berikan nilai NULL di database
    if (empty($foto)) {
        // Query disesuaikan untuk menyertakan 'harga'
        $query = "INSERT INTO barang (nama_barang, harga, foto, stock) VALUES ('$nama_barang', '$harga', NULL, '$stock')";
    } else {
        // Query disesuaikan untuk menyertakan 'harga'
        $query = "INSERT INTO barang (nama_barang, harga, foto, stock) VALUES ('$nama_barang', '$harga', '$foto', '$stock')";
    }
    
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Error: " . mysqli_error($conn));
    }
    return $result;
}

function updateBarang($id, $nama_barang, $foto, $stock) {
    global $conn;
    if (!$conn) {
        die("Koneksi database tidak tersedia");
    }
    
    // Handle foto kosong
    if (empty($foto)) {
        $query = "UPDATE barang SET nama_barang='$nama_barang', stock='$stock' WHERE id_barang='$id'";
    } else {
        $query = "UPDATE barang SET nama_barang='$nama_barang', foto='$foto', stock='$stock' WHERE id_barang='$id'";
    }
    
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Error: " . mysqli_error($conn));
    }
    return $result;
}

function deleteBarang($id) {
    global $conn;
    if (!$conn) {
        die("Koneksi database tidak tersedia");
    }
    $query = "DELETE FROM barang WHERE id_barang='$id'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Error: " . mysqli_error($conn));
    }
    return $result;
}
?>