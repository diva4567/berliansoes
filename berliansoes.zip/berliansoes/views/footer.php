<?php 
// File: views/footer.php
// $company_name bisa didefinisikan di file view utama atau di sini
$company_name = 'BERLIANSOES'; 
?>

</main>

<footer class="bg-gray-100 border-t border-gray-200 mt-auto">
    <div class="container mx-auto px-4 py-4">
        <div class="text-center text-sm text-gray-600">
            &copy; <?= date('Y') ?> **<?= $company_name ?>**. Inventory Management System BERLIANSOES.
        </div>
    </div>
</footer>
</body>
</html>