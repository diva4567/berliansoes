<?php 
// File: views/navbar.php
// Pastikan variabel $logo_exists dan $logo_path sudah didefinisikan 
// di file view utama (misalnya index.php, edit_form.php) sebelum di-include.
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'BERLIANSOES' ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        // Konfigurasi Tailwind CSS (dari kode Anda)
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3b82f6', success: '#10b981', danger: '#ef4444',
                    }
                }
            }
        }
    </script>
    <style>
        .header-bg { background-color: #3b82f6; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .input-text { border: 1px solid #d1d5db; padding: 0.5rem 0.75rem; border-radius: 0.375rem; width: 100%; transition: border-color 0.15s ease-in-out; }
        .input-text:focus { border-color: #3b82f6; outline: none; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2); }
        .file-input-style { /* Tambahkan style custom untuk input file jika perlu */ }
        .btn-submit { background-color: var(--primary); color: white; padding: 0.5rem 1rem; border-radius: 0.375rem; transition: background-color 0.15s; }
        .btn-submit:hover { background-color: #2563eb; }
        .btn-cancel { background-color: #6b7280; color: white; padding: 0.5rem 1rem; border-radius: 0.375rem; transition: background-color 0.15s; }
        .btn-cancel:hover { background-color: #4b5563; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">

<header class="header-bg sticky top-0 z-10">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <div class="flex items-center space-x-3">
            <?php if (isset($logo_exists) && $logo_exists): ?>
                <img src="<?= $logo_path ?>" alt="Logo Perusahaan" class="h-10 w-auto">
            <?php endif; ?>
            <span class="text-xl font-bold text-white">BERLIANSOES</span>
        </div>
        
        <nav class="hidden md:flex space-x-6">
            <a href="index.php" class="text-white hover:text-gray-200 transition duration-150 <?= $current_page === 'index.php' ? 'font-bold underline' : '' ?>">
                Soes Kering Aneka Rasa
            </a>
        
            </nav>

        <a href="tambah_form.php" class="md:hidden text-white bg-green-500 hover:bg-green-600 px-3 py-1 rounded-md text-sm font-medium">
            <i class="fas fa-plus"></i>
        </a>

    </div>
</header>
<main class="flex-grow container mx-auto px-4 py-8">