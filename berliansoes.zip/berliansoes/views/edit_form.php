<?php
// File: views/edit_form.php
require_once '../models/config.php';
require_once '../models/function.php';

// Cek koneksi database
if (!$conn) {
    die("Koneksi database gagal. Periksa config.php");
}

$id = $_GET['id'] ?? 0;
// 1. Ambil data barang yang akan diedit
$barang = $id ? getBarangById($id) : null;

if (!$barang) {
    // Arahkan kembali jika ID tidak valid atau barang tidak ditemukan
    header('Location: index.php?error=notfound');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang: <?= htmlspecialchars($barang['nama_barang']) ?> | BERLIANSOES</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 font-sans">
    
    <?php include 'navbar.php'; ?>

    <main class="container mx-auto px-4 py-8">
        <div class="max-w-xl mx-auto">
            <div class="bg-white p-6 border border-gray-300 rounded-lg shadow-lg">
                <div class="mb-6 border-b pb-4">
                    <h2 class="text-2xl font-semibold text-gray-800 flex items-center">
                        <i class="fas fa-pen-to-square text-green-600 mr-2"></i> Edit Barang: <?= htmlspecialchars($barang['nama_barang']) ?>
                    </h2>
                    <p class="text-sm text-gray-500 mt-1">Sesuaikan informasi barang</p>
                </div>
                
                <?php if (isset($_GET['error']) && $_GET['error'] == 'edit'): ?>
                    <div class="bg-red-100 border border-red-400 text-red-600 px-4 py-2 rounded-md mb-6 text-sm">
                        <strong class="font-bold">Gagal!</strong>
                        <span>Terdapat kesalahan saat menyimpan. Coba cek lagi datanya.</span>
                    </div>
                <?php endif; ?>
                
                <form action="../controllers/edit_barang.php" method="POST" enctype="multipart/form-data">
                    
                    <input type="hidden" name="id_barang" value="<?= htmlspecialchars($barang['id_barang']) ?>">
                    <input type="hidden" name="foto_lama" value="<?= htmlspecialchars($barang['foto'] ?? '') ?>">

                    <div class="mb-4">
                        <label for="nama_barang" class="block text-sm font-medium text-gray-700 mb-2">Nama Barang <span class="text-red-500">*</span></label>
                        <input type="text" id="nama_barang" name="nama_barang" required
                            value="<?= htmlspecialchars($barang['nama_barang']) ?>"
                            class="w-full border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            placeholder="Masukkan nama barang">
                    </div>

                    <div class="mb-4">
                        <label for="harga" class="block text-sm font-medium text-gray-700 mb-2">Harga <span class="text-red-500">*</span></label>
                        <input type="number" id="harga" name="harga" required min="0" 
                            value="<?= htmlspecialchars($barang['harga'] ?? 0) ?>"
                            class="w-full border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            placeholder="Masukkan harga jual">
                    </div>
                    
                    <div class="mb-4">
                        <label for="stock" class="block text-sm font-medium text-gray-700 mb-2">Stok <span class="text-red-500">*</span></label>
                        <input type="number" id="stock" name="stock" required min="0" 
                            value="<?= htmlspecialchars($barang['stock'] ?? 0) ?>"
                            class="w-full border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            placeholder="Jumlah stok">
                    </div>

                    <div class="mb-4">
                        <label for="foto" class="block text-sm font-medium text-gray-700 mb-2">Ganti Foto Barang</label>
                        <input type="file" id="foto" name="foto" accept="image/*" 
                            class="w-full text-sm border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200">
                        <small class="text-xs text-gray-500 mt-1 block">Kosongkan jika tidak ingin mengubah foto</small>
                    </div>

                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Foto Saat Ini</label>
                        <?php 
                        $foto_path = "../assets/img/" . $barang['foto'];
                        $foto_exists = !empty($barang['foto']) && file_exists($foto_path);
                        ?>
                        
                        <?php if ($foto_exists): ?>
                            <img src="<?= $foto_path ?>" alt="Foto Saat Ini" 
                                class="w-20 h-20 object-cover rounded-md border border-gray-200">
                        <?php else: ?>
                            <div class="w-20 h-20 bg-gray-200 rounded-md flex items-center justify-center text-xs text-gray-500">
                                No Photo
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="flex justify-end space-x-2 pt-4 border-t border-gray-200">
                        <a href="index.php" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded inline-flex items-center space-x-1 transition">
                            <i class="fas fa-arrow-left"></i> <span>Batal</span>
                        </a>
                        <button type="submit" name="submit_edit" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded inline-flex items-center space-x-1 transition">
                            <i class="fas fa-save"></i> <span>Simpan Perubahan</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>
    
    <?php include 'footer.php'; ?>
    
</body>
</html>