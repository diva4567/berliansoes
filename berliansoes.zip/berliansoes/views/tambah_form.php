<?php
// File: views/tambah_form.php
require_once '../models/config.php';
require_once '../models/function.php';

// Cek koneksi database
if (!$conn) {
    die("Koneksi database gagal. Periksa config.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang | YULIARASA</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 font-sans">
    
    <?php include 'navbar.php'; ?>

    <main class="container mx-auto px-4 py-8">
        <div class="max-w-md mx-auto">
            <div class="bg-white p-6 border border-gray-300 rounded-lg shadow-lg">
                <div class="mb-6 border-b pb-4">
                    <p class="text-sm text-gray-500 mt-1">Isi formulir untuk menambahkan barang baru</p>
                </div>

                <?php if (isset($_GET['error']) && $_GET['error'] == 'tambah'): ?>
                    <div class="bg-red-100 border border-red-400 text-red-600 px-4 py-2 rounded-md mb-6 text-sm">
                        <strong class="font-bold">Gagal!</strong>
                        <span>Ada kendala saat menyimpan data. Coba cek lagi semua isiannya.</span>
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['success']) && $_GET['success'] == 'tambah'): ?>
                    <div class="bg-green-100 border border-green-400 text-green-600 px-4 py-2 rounded-md mb-6 text-sm">
                        <strong class="font-bold">Berhasil!</strong>
                        <span>Barang berhasil ditambahkan!</span>
                    </div>
                <?php endif; ?>
                
                <form action="../controllers/tambah_barang.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-4">
                        <label for="nama_barang" class="block text-sm font-medium text-gray-700 mb-2">Nama Barang <span class="text-red-500">*</span></label>
                        <input type="text" id="nama_barang" name="nama_barang" required 
                            class="w-full border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            placeholder="Masukkan nama barang">
                    </div>
                    
                    <div class="mb-4">
                        <label for="harga" class="block text-sm font-medium text-gray-700 mb-2">Harga <span class="text-red-500">*</span></label>
                        <input type="number" id="harga" name="harga" required min="0"
                            class="w-full border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            placeholder="Masukkan harga jual">
                    </div>

                    <div class="mb-4">
                        <label for="stock" class="block text-sm font-medium text-gray-700 mb-2">Stok Awal <span class="text-red-500">*</span></label>
                        <input type="number" id="stock" name="stock" required min="0"
                            class="w-full border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
                            placeholder="Jumlah stok awal">
                    </div>

                    <div class="mb-6">
                        <label for="foto" class="block text-sm font-medium text-gray-700 mb-2">Foto Barang</label>
                        <input type="file" id="foto" name="foto" accept="image/*" 
                            class="w-full text-sm border border-gray-300 px-3 py-2 rounded focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200">
                        <small class="text-xs text-gray-500 mt-1 block">Format: JPG, PNG, JPEG · Maksimal 2MB</small>
                    </div>

                    <div class="flex justify-end space-x-2 pt-4 border-t border-gray-200">
                        <a href="index.php" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded inline-flex items-center space-x-1 transition">
                            <i class="fas fa-arrow-left"></i> <span>Kembali</span>
                        </a>
                        <button type="submit" name="submit_tambah" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded inline-flex items-center space-x-1 transition">
                            <i class="fas fa-save"></i> <span>Simpan</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>
    
    <?php include 'footer.php'; ?>
    
</body>
</html>