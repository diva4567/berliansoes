<?php
// File: views/detail.php
require_once '../models/config.php';
require_once '../models/function.php';

// Cek koneksi database
if (!$conn) {
    die("Koneksi database gagal. Periksa config.php");
}

// 1. Ambil ID dari URL
$id = $_GET['id'] ?? 0;

// 2. Ambil data barang berdasarkan ID
$barang = $id ? getBarangById($id) : null;

// 3. Cek apakah barang ditemukan
if (!$barang) {
    header('Location: index.php?error=notfound');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Barang: <?= htmlspecialchars($barang['nama_barang']) ?> | YULIARASA</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 font-sans">
    
    <?php include 'navbar.php'; ?>
    
    <main class="container mx-auto px-4 py-8">
        <div class="max-w-4xl mx-auto">
            <div class="mb-6 border-b pb-4">
                <h2 class="text-3xl font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-info-circle text-blue-600 mr-3"></i> Detail Barang
                </h2>
                <p class="text-lg text-gray-500 mt-1">Informasi Lengkap Produk <strong><?= htmlspecialchars($barang['nama_barang']) ?></strong></p>
            </div>
            
            <div class="bg-white p-6 border border-gray-300 rounded-lg shadow-lg">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    <div class="md:col-span-1">
                        <h3 class="text-lg font-semibold text-gray-700 mb-3 border-b pb-2">Foto Barang</h3>
                        <?php 
                        $foto_path = "../assets/img/" . $barang['foto'];
                        $foto_exists = !empty($barang['foto']) && file_exists($foto_path);
                        ?>
                        
                        <?php if ($foto_exists): ?>
                            <img src="<?= $foto_path ?>" alt="Foto Barang: <?= htmlspecialchars($barang['nama_barang']) ?>" 
                                class="w-full h-auto object-cover rounded-lg border border-gray-200 shadow-md">
                        <?php else: ?>
                            <div class="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center text-xl text-gray-500 border border-gray-300">
                                <i class="fas fa-camera mr-2"></i> Tidak Ada Foto
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="md:col-span-2 space-y-4">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4 border-b pb-2">Data Barang</h3>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div class="space-y-1">
                                <p class="text-sm font-medium text-gray-600">ID Barang</p>
                                <p class="text-base font-mono bg-gray-100 px-3 py-1 rounded"><?= $barang['id_barang'] ?></p>
                            </div>
                            <div class="space-y-1">
                                <p class="text-sm font-medium text-gray-600">Nama Barang</p>
                                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($barang['nama_barang']) ?></p>
                            </div>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div class="space-y-1">
                                <p class="text-sm font-medium text-gray-600">Harga</p>
                                <p class="text-xl font-bold text-green-600">
                                    Rp <?= number_format($barang['harga'], 0, ',', '.') ?>
                                </p>
                            </div>

                            <div class="space-y-1">
                                <p class="text-sm font-medium text-gray-600">Stok</p>
                                <p class="text-xl font-bold <?= $barang['stock'] > 0 ? 'text-blue-600' : 'text-red-600' ?>">
                                    <?= $barang['stock'] ?> pcs
                                </p>
                            </div>
                        </div>

                        <div class="pt-4 border-t border-gray-200 flex justify-start space-x-3">
                            <a href="index.php" 
                                class="inline-flex items-center space-x-1 bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md text-sm font-medium transition duration-150">
                                <i class="fas fa-arrow-left"></i> <span>Kembali</span>
                            </a>
                            <a href="edit_form.php?id=<?= $barang['id_barang'] ?>" 
                                class="inline-flex items-center space-x-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium transition duration-150">
                                <i class="fas fa-pen-to-square"></i> <span>Edit</span>
                            </a>
                            <a href="../controllers/delete_barang.php?id=<?= $barang['id_barang'] ?>" 
                                class="inline-flex items-center space-x-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium transition duration-150"
                                onclick="return confirm('Yakin hapus barang: <?= htmlspecialchars($barang['nama_barang']) ?>?')">
                                <i class="fas fa-trash"></i> <span>Hapus</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'footer.php'; ?>
    
</body>
</html>