<?php
// File: views/index.php
require_once '../models/config.php';
require_once '../models/function.php';

// Cek koneksi database
if (!$conn) {
    die("Koneksi database gagal. Periksa config.php");
}

// 1. AMBIL KEYWORD PENCARIAN
$keyword = $_GET['search'] ?? '';

// 2. LOGIKA PENCARIAN
$sql_query = "SELECT * FROM barang";
if (!empty($keyword)) {
    $is_numeric = is_numeric($keyword);
    if ($is_numeric) {
        // Cari berdasarkan stok atau harga
        $sql_query .= " WHERE stock = '" . mysqli_real_escape_string($conn, $keyword) . "' OR harga = '" . mysqli_real_escape_string($conn, $keyword) . "'";
    } else {
        // Cari berdasarkan nama
        $sql_query .= " WHERE nama_barang LIKE '%" . mysqli_real_escape_string($conn, $keyword) . "%'";
    }
}
$sql_query .= " ORDER BY id_barang DESC";
$result_query = mysqli_query($conn, $sql_query);

$barang = [];
if ($result_query) {
    while ($row = mysqli_fetch_assoc($result_query)) {
        $barang[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Barang | YULIARASA</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 font-sans">
    
    <?php include 'navbar.php'; ?>
    <main class="container mx-auto px-4 py-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-6">
            
            <div class="flex items-center space-x-3 text-2xl font-semibold text-gray-700 w-full md:w-auto">
                <i class="fas fa-boxes-stacked text-blue-600"></i>
                <span>Daftar Barang</span>
            </div>
            
            <div class="flex flex-col items-end w-full md:w-auto space-y-3">
                
                <a href="tambah_form.php" class="inline-flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition shadow-md">
                    <i class="fas fa-plus mr-2"></i> Tambah Barang
                </a>

                <form method="GET" action="index.php" class="w-full flex items-center space-x-2">
                    <div class="relative w-full">
                        <input type="text" name="search" placeholder="Cari Nama/Stok/Harga..." value="<?= htmlspecialchars($keyword) ?>"
                               class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-sm">
                        <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
                    </div>
                    <button type="submit" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-2 rounded-md text-sm transition">
                        Cari
                    </button>
                    <?php if (!empty($keyword)): ?>
                        <a href="index.php" class="text-red-600 hover:text-red-700 text-sm p-2" title="Hapus Pencarian">
                            <i class="fas fa-times-circle"></i>
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <div class="text-sm text-gray-600 mb-4">
            <?php if (!empty($keyword)): ?>
                Menampilkan hasil untuk: <strong><?= htmlspecialchars($keyword) ?></strong> |
            <?php endif; ?>
            Total Item: <span class="font-bold text-blue-600"><?= count($barang) ?></span>
        </div>
        
        <?php if (empty($barang)): ?>
            <div class="bg-gray-100 border border-gray-300 p-8 text-center rounded-lg mt-10">
                <i class="fas fa-list-ul text-4xl text-gray-400 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-700">
                    <?php if (!empty($keyword)): ?>
                        Data "<?= htmlspecialchars($keyword) ?>" tidak ditemukan.
                    <?php else: ?>
                        Belum ada data barang.
                    <?php endif; ?>
                </h3>
                <p class="text-gray-500 mt-2">Ayo, masukkan data pertamamu!</p>
            </div>
        <?php else: ?>
            <div class="border border-gray-300 rounded-lg overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-gray-100 border-b border-gray-300">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">No</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Foto</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Nama Barang</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Harga</th> 
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Stok</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php $no = 1; ?>
                            <?php foreach ($barang as $item): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-800"><?= $no++ ?></td>
                                <td class="px-4 py-3">
                                    <?php 
                                    $foto_path = "../assets/img/" . $item['foto'];
                                    $foto_exists = !empty($item['foto']) && file_exists($foto_path);
                                    ?>
                                    
                                    <?php if ($foto_exists): ?>
                                        <img src="<?= $foto_path ?>" alt="Foto Barang" class="w-10 h-10 object-cover rounded-md border border-gray-200">
                                    <?php else: ?>
                                        <div class="w-10 h-10 bg-gray-200 rounded-md flex items-center justify-center text-xs text-gray-500">
                                            No Image
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-sm font-medium text-gray-900"><?= htmlspecialchars($item['nama_barang']) ?></td>
                                <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-800">Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                                <td class="px-4 py-3">
                                    <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium 
                                        <?= $item['stock'] > 0 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600' ?>">
                                        <?php if ($item['stock'] > 0): ?>
                                            <i class="fas fa-check mr-1"></i>
                                        <?php else: ?>
                                            <i class="fas fa-times mr-1"></i>
                                        <?php endif; ?>
                                        <?= $item['stock'] ?> pcs
                                    </span>
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex space-x-3">
                                        <a href="detail.php?id=<?= $item['id_barang'] ?>" 
                                            class="text-green-600 hover:text-green-700 text-sm">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>
                                        <a href="edit_form.php?id=<?= $item['id_barang'] ?>" 
                                            class="text-yellow-600 hover:text-yellow-700 text-sm">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="../controllers/delete_barang.php?id=<?= $item['id_barang'] ?>" 
                                            class="text-red-600 hover:text-red-700 text-sm"
                                            onclick="return confirm('Yakin hapus barang: <?= htmlspecialchars($item['nama_barang']) ?>?')">
                                            <i class="fas fa-trash"></i> Hapus
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </main>
    
    <?php include 'footer.php'; ?>
    
</body>
</html>