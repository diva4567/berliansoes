<?php
require_once '../models/config.php';
require_once '../models/function.php';

// PROSES HAPUS BARANG
$id = $_GET['id'] ?? 0;

if ($id) {
    // Ambil data barang untuk hapus foto
    $barang = getBarangById($id);
    
    if ($barang) {
        $foto_path = "../assets/img/" . $barang['foto'];
        if ($barang['foto'] && file_exists($foto_path)) {
            unlink($foto_path);
        }
        
        // Hapus dari database
        if (deleteBarang($id)) {
            header('Location: ../views/index.php?sukses=hapus');
        } else {
            header('Location: ../views/index.php?error=hapus');
        }
    } else {
        header('Location: ../views/index.php?error=notfound');
    }
} else {
    header('Location: ../views/index.php');
}
?>