<?php
require_once '../models/config.php';
require_once '../models/function.php';

// PROSES TAMBAH BARANG
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_barang = mysqli_real_escape_string($conn, $_POST['nama_barang']);
    $harga = intval($_POST['harga']); 
    $stock = intval($_POST['stock']);
    
    // Handle upload foto
    $foto = '';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $folder = "../assets/img/"; 
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }
        
        $ekstensi = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($ekstensi, $allowed_extensions)) {
            $nama_file = uniqid() . '.' . $ekstensi;
            $target = $folder . $nama_file;
            
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $target)) {
                $foto = $nama_file;
            }
        }
    }
    if (tambahBarang($nama_barang, $harga, $foto, $stock)) { 
        header('Location: ../views/index.php?sukses=tambah');
    } else {
        header('Location: ../views/tambah_form.php?error=tambah');
    }
    exit;
}
?>