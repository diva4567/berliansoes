<?php
require_once '../models/config.php';
require_once '../models/function.php';

// PROSES EDIT BARANG (Ketika form dikirimkan)
if ($_POST) {
    $id_barang = $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $stock = $_POST['stock'];
    $foto_lama = $_POST['foto_lama'];
    
    $foto = $foto_lama;
    
    // Handle upload foto baru
    if ($_FILES['foto']['error'] == 0) {
        // Hapus foto lama, harus menggunakan ../assets/img/
        if ($foto_lama && file_exists("../assets/img/$foto_lama")) {
            unlink("../assets/img/$foto_lama");
        }
        
        // Upload foto baru
        $folder = "../assets/img/";
        $ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nama_file = uniqid() . '.' . $ekstensi;
        $target = $folder . $nama_file;
        
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $target)) {
            $foto = $nama_file;
        }
    }
    
    // Update database
    if (updateBarang($id_barang, $nama_barang, $foto, $stock)) {
        header('Location: ../views/index.php?sukses=edit');
    } else {
        header('Location: ../views/edit_form.php?error=edit&id=' . $id_barang);
    }
    exit;
}

// TAMPILKAN FORM EDIT 
$id = $_GET['id'] ?? 0;
if ($id) {
    $barang = getBarangById($id);
    if ($barang) {
        include '../views/edit_form.php';
    } else {
        header('Location: ../views/index.php?error=notfound');
    }
} else {
    header('Location: ../views/index.php');
}
?>